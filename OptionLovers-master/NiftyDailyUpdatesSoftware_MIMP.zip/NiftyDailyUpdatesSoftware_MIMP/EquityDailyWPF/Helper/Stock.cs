﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EquityDailyWPF.Helper
{
    public class Stock
    {
        public string stocksUrl {get; set;}

        public string stockRsiLink { get; set; }

    }
}
