﻿
Trendlyn:



Wipro:


https://trendlyne.com/equity/technical-analysis/WIPRO/1526/wipro-ltd/

RSI(14)
on Mar-5 RSI is 32.7 at 11 am


<div class="stcard-title gr fs09rem shrink-text text-ellipsis" data-title="RSI"><span>RSI</span></div>
<div class="stcard-rating positive"><span class="fs1p7rem fw500">28.6</span></div>

https://trendlyne.com/equity/technical-analysis/SBIN/1193/state-bank-of-india/

RSI(14)
on Mar-5 RSI is 37.6 at 11 am

<div class="stcard-title gr fs09rem shrink-text text-ellipsis" data-title="RSI"><span>RSI</span></div>

<div class="stcard-rating neutral"><span class="fs1p7rem fw500">34.5</span></div>

fs1p7rem fw500

Momemntum Score indicator:

The Momentum Score combines over 20 key technical indicators to calculate the stock's technical strength in the market. 
The momentum score is recalculated at the end of trading day between 5pm and 7pm on most days.

Score is 17.0, stock is technically weak. Stocks with score below 35 or in the bottom 30% are considered as technically weak

Score is 29.0, stock is technically weak. Stocks with score below 35 or in the bottom 30% are considered as technically weak

Score is 54.0, stock is technically neutral.

Stocks with score above 70 are considered as technically Strong and below 35 are considered weak.







